import { useState, useEffect } from 'react'
import { Button } from '@/components/ui/button.jsx'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card.jsx'
import { Badge } from '@/components/ui/badge.jsx'
import { Input } from '@/components/ui/input.jsx'
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog.jsx'
import { TrendingUp, TrendingDown, DollarSign, BarChart3, Bell, Settings, Plus, AlertTriangle } from 'lucide-react'
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, AreaChart, Area } from 'recharts'
import { getCurrentPrice, getHistoricalPrices, getEconomicFactors, getRecommendations, getAlerts, createAlert, deleteAlert } from './lib/api'
import './App.css'

function App() {
  const [currentPrice, setCurrentPrice] = useState(null)
  const [priceChange, setPriceChange] = useState(null)
  const [percentageChange, setPercentageChange] = useState(null)
  const [selectedTimeframe, setSelectedTimeframe] = useState('1Y')
  const [historicalPrices, setHistoricalPrices] = useState([])
  const [economicFactors, setEconomicFactors] = useState([])
  const [recommendations, setRecommendations] = useState([])
  const [alerts, setAlerts] = useState([])
  const [newAlert, setNewAlert] = useState({ type: 'price_above', value: '' })
  const [loading, setLoading] = useState({
    price: true,
    historical: true,
    factors: true,
    recommendations: true,
    alerts: true
  })
  const [error, setError] = useState({
    price: null,
    historical: null,
    factors: null,
    recommendations: null,
    alerts: null
  })

  // Fetch current price with regular updates
  useEffect(() => {
    const fetchPrice = async () => {
      try {
        const data = await getCurrentPrice()
        setCurrentPrice(data.price)
        setPriceChange(data.change)
        setPercentageChange(data.percentage_change)
        setLoading(prev => ({ ...prev, price: false }))
      } catch (err) {
        console.error('Error fetching current price:', err)
        setError(prev => ({ ...prev, price: 'فشل في جلب السعر الحالي' }))
        setLoading(prev => ({ ...prev, price: false }))
      }
    }

    // Initial fetch
    fetchPrice()

    // Set up interval for regular updates
    const interval = setInterval(fetchPrice, 5000)

    return () => clearInterval(interval)
  }, [])

  // Fetch historical prices when timeframe changes
  useEffect(() => {
    const fetchHistoricalPrices = async () => {
      setLoading(prev => ({ ...prev, historical: true }))
      try {
        const data = await getHistoricalPrices(selectedTimeframe)
        setHistoricalPrices(data)
        setLoading(prev => ({ ...prev, historical: false }))
      } catch (err) {
        console.error('Error fetching historical prices:', err)
        setError(prev => ({ ...prev, historical: 'فشل في جلب البيانات التاريخية' }))
        setLoading(prev => ({ ...prev, historical: false }))
      }
    }

    fetchHistoricalPrices()
  }, [selectedTimeframe])

  // Fetch economic factors
  useEffect(() => {
    const fetchEconomicFactors = async () => {
      try {
        const data = await getEconomicFactors()
        setEconomicFactors(data)
        setLoading(prev => ({ ...prev, factors: false }))
      } catch (err) {
        console.error('Error fetching economic factors:', err)
        setError(prev => ({ ...prev, factors: 'فشل في جلب العوامل الاقتصادية' }))
        setLoading(prev => ({ ...prev, factors: false }))
      }
    }

    fetchEconomicFactors()
  }, [])

  // Fetch recommendations
  useEffect(() => {
    const fetchRecommendations = async () => {
      try {
        const data = await getRecommendations()
        setRecommendations(data)
        setLoading(prev => ({ ...prev, recommendations: false }))
      } catch (err) {
        console.error('Error fetching recommendations:', err)
        setError(prev => ({ ...prev, recommendations: 'فشل في جلب التوصيات' }))
        setLoading(prev => ({ ...prev, recommendations: false }))
      }
    }

    fetchRecommendations()
  }, [])

  // Fetch alerts
  useEffect(() => {
    const fetchAlerts = async () => {
      try {
        const data = await getAlerts()
        setAlerts(data)
        setLoading(prev => ({ ...prev, alerts: false }))
      } catch (err) {
        console.error('Error fetching alerts:', err)
        setError(prev => ({ ...prev, alerts: 'فشل في جلب التنبيهات' }))
        setLoading(prev => ({ ...prev, alerts: false }))
      }
    }

    fetchAlerts()
  }, [])

  // Handle creating a new alert
  const handleCreateAlert = async () => {
    if (!newAlert.value) return

    try {
      await createAlert(newAlert)
      // Refresh alerts
      const data = await getAlerts()
      setAlerts(data)
      // Reset form
      setNewAlert({ type: 'price_above', value: '' })
    } catch (err) {
      console.error('Error creating alert:', err)
    }
  }

  // Handle deleting an alert
  const handleDeleteAlert = async (alertId) => {
    try {
      await deleteAlert(alertId)
      // Refresh alerts
      const data = await getAlerts()
      setAlerts(data)
    } catch (err) {
      console.error('Error deleting alert:', err)
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-blue-900 to-slate-800 text-white">
      {/* Header */}
      <header className="border-b border-slate-700 bg-slate-900/50 backdrop-blur-sm">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <div className="flex items-center space-x-2">
                <DollarSign className="h-8 w-8 text-yellow-400" />
                <h1 className="text-2xl font-bold bg-gradient-to-r from-yellow-400 to-yellow-600 bg-clip-text text-transparent">
                  توقعات الذهب
                </h1>
              </div>
            </div>
            <div className="flex items-center space-x-4">
              <Dialog>
                <DialogTrigger asChild>
                  <Button variant="outline" size="sm">
                    <Bell className="h-4 w-4 mr-2" />
                    التنبيهات
                  </Button>
                </DialogTrigger>
                <DialogContent className="bg-slate-800 border-slate-700">
                  <DialogHeader>
                    <DialogTitle>إدارة التنبيهات</DialogTitle>
                    <DialogDescription>
                      إنشاء تنبيهات لأسعار الذهب وإدارتها
                    </DialogDescription>
                  </DialogHeader>
                  
                  {/* Current Alerts */}
                  <div className="space-y-4 my-4">
                    <h4 className="font-medium">التنبيهات الحالية</h4>
                    {loading.alerts ? (
                      <p className="text-sm text-slate-400">جاري التحميل...</p>
                    ) : error.alerts ? (
                      <p className="text-sm text-red-400">{error.alerts}</p>
                    ) : alerts.length === 0 ? (
                      <p className="text-sm text-slate-400">لا توجد تنبيهات حالية</p>
                    ) : (
                      <div className="space-y-2">
                        {alerts.map((alert) => (
                          <div key={alert.id} className="flex items-center justify-between p-2 bg-slate-700/30 rounded-lg">
                            <div className="flex items-center">
                              <AlertTriangle className="h-4 w-4 text-yellow-400 mr-2" />
                              <span>
                                {alert.type === 'price_above' ? 'السعر أعلى من' : 'السعر أقل من'} ${alert.value}
                              </span>
                            </div>
                            <Button 
                              variant="ghost" 
                              size="sm" 
                              onClick={() => handleDeleteAlert(alert.id)}
                            >
                              حذف
                            </Button>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                  
                  {/* Create New Alert */}
                  <div className="space-y-4">
                    <h4 className="font-medium">إنشاء تنبيه جديد</h4>
                    <div className="flex space-x-2">
                      <select 
                        className="bg-slate-700 border-slate-600 rounded-md p-2 text-sm"
                        value={newAlert.type}
                        onChange={(e) => setNewAlert({ ...newAlert, type: e.target.value })}
                      >
                        <option value="price_above">السعر أعلى من</option>
                        <option value="price_below">السعر أقل من</option>
                      </select>
                      <Input 
                        type="number" 
                        placeholder="السعر" 
                        className="bg-slate-700 border-slate-600"
                        value={newAlert.value}
                        onChange={(e) => setNewAlert({ ...newAlert, value: e.target.value })}
                      />
                    </div>
                  </div>
                  
                  <DialogFooter>
                    <Button onClick={handleCreateAlert}>إنشاء التنبيه</Button>
                  </DialogFooter>
                </DialogContent>
              </Dialog>
              
              <Button variant="outline" size="sm">
                <Settings className="h-4 w-4 mr-2" />
                الإعدادات
              </Button>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-8">
        {/* Hero Section */}
        <div className="text-center mb-12">
          <h2 className="text-4xl font-bold mb-4">
            منصة التحليل والتنبؤ لأسعار الذهب
          </h2>
          <p className="text-xl text-slate-300 mb-8">
            تحليل شامل للعوامل المؤثرة على أسعار الذهب مع توقعات دقيقة مدعومة بالذكاء الاصطناعي
          </p>
          
          {/* Current Price Display */}
          <Card className="max-w-md mx-auto bg-gradient-to-r from-yellow-500/10 to-yellow-600/10 border-yellow-500/20">
            <CardHeader className="text-center">
              {loading.price ? (
                <CardTitle className="text-3xl font-bold text-yellow-400">
                  جاري التحميل...
                </CardTitle>
              ) : error.price ? (
                <CardTitle className="text-xl font-bold text-red-400">
                  {error.price}
                </CardTitle>
              ) : (
                <>
                  <CardTitle className="text-3xl font-bold text-yellow-400">
                    ${currentPrice?.toFixed(2)}
                  </CardTitle>
                  <CardDescription className="flex items-center justify-center space-x-2">
                    {priceChange >= 0 ? (
                      <TrendingUp className="h-4 w-4 text-green-400" />
                    ) : (
                      <TrendingDown className="h-4 w-4 text-red-400" />
                    )}
                    <span className={priceChange >= 0 ? 'text-green-400' : 'text-red-400'}>
                      {priceChange >= 0 ? '+' : ''}{priceChange?.toFixed(2)} ({percentageChange?.toFixed(2)}%)
                    </span>
                  </CardDescription>
                </>
              )}
            </CardHeader>
          </Card>
        </div>

        {/* Charts Section */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 mb-12">
          {/* Main Price Chart */}
          <Card className="lg:col-span-2 bg-slate-800/50 border-slate-700">
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle className="flex items-center space-x-2">
                  <BarChart3 className="h-5 w-5 text-yellow-400" />
                  <span>تطور أسعار الذهب</span>
                </CardTitle>
                <div className="flex space-x-2">
                  {['1M', '3M', '6M', '1Y'].map((timeframe) => (
                    <Button
                      key={timeframe}
                      variant={selectedTimeframe === timeframe ? 'default' : 'outline'}
                      size="sm"
                      onClick={() => setSelectedTimeframe(timeframe)}
                    >
                      {timeframe}
                    </Button>
                  ))}
                </div>
              </div>
            </CardHeader>
            <CardContent>
              {loading.historical ? (
                <div className="h-[300px] flex items-center justify-center">
                  <p>جاري تحميل البيانات...</p>
                </div>
              ) : error.historical ? (
                <div className="h-[300px] flex items-center justify-center">
                  <p className="text-red-400">{error.historical}</p>
                </div>
              ) : (
                <ResponsiveContainer width="100%" height={300}>
                  <AreaChart data={historicalPrices}>
                    <defs>
                      <linearGradient id="goldGradient" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor="#fbbf24" stopOpacity={0.3}/>
                        <stop offset="95%" stopColor="#fbbf24" stopOpacity={0}/>
                      </linearGradient>
                    </defs>
                    <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
                    <XAxis dataKey="date" stroke="#9ca3af" />
                    <YAxis stroke="#9ca3af" />
                    <Tooltip 
                      contentStyle={{ 
                        backgroundColor: '#1f2937', 
                        border: '1px solid #374151',
                        borderRadius: '8px'
                      }}
                    />
                    <Area 
                      type="monotone" 
                      dataKey="price" 
                      stroke="#fbbf24" 
                      strokeWidth={2}
                      fill="url(#goldGradient)" 
                    />
                  </AreaChart>
                </ResponsiveContainer>
              )}
            </CardContent>
          </Card>

          {/* Economic Factors */}
          <Card className="bg-slate-800/50 border-slate-700">
            <CardHeader>
              <CardTitle>العوامل الاقتصادية المؤثرة</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {loading.factors ? (
                <p className="text-center">جاري تحميل البيانات...</p>
              ) : error.factors ? (
                <p className="text-center text-red-400">{error.factors}</p>
              ) : (
                economicFactors.map((factor, index) => (
                  <div key={index} className="flex items-center justify-between p-3 bg-slate-700/30 rounded-lg">
                    <div>
                      <p className="font-medium">{factor.name}</p>
                      <p className="text-sm text-slate-400">{factor.value}%</p>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Badge variant={factor.impact === 'إيجابي' ? 'default' : 'destructive'}>
                        {factor.impact}
                      </Badge>
                      {factor.trend === 'up' ? (
                        <TrendingUp className="h-4 w-4 text-green-400" />
                      ) : (
                        <TrendingDown className="h-4 w-4 text-red-400" />
                      )}
                    </div>
                  </div>
                ))
              )}
            </CardContent>
          </Card>
        </div>

        {/* Recommendations Section */}
        <Card className="bg-slate-800/50 border-slate-700 mb-8">
          <CardHeader>
            <CardTitle>التوصيات الذكية</CardTitle>
            <CardDescription>
              توصيات مبنية على تحليل البيانات والذكاء الاصطناعي
            </CardDescription>
          </CardHeader>
          <CardContent>
            {loading.recommendations ? (
              <p className="text-center">جاري تحميل البيانات...</p>
            ) : error.recommendations ? (
              <p className="text-center text-red-400">{error.recommendations}</p>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                {recommendations.map((rec, index) => (
                  <div key={index} className="p-4 bg-slate-700/30 rounded-lg">
                    <div className="flex items-center justify-between mb-2">
                      <Badge variant={rec.type === 'شراء' ? 'default' : rec.type === 'احتفاظ' ? 'secondary' : 'outline'}>
                        {rec.type}
                      </Badge>
                      <span className="text-sm text-slate-400">{rec.confidence}% ثقة</span>
                    </div>
                    <p className="text-sm text-slate-300">{rec.reason}</p>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>

        {/* Footer */}
        <footer className="text-center text-slate-400 py-8">
          <p>© 2024 منصة توقعات أسعار الذهب. جميع الحقوق محفوظة.</p>
          <p className="text-sm mt-2">
            البيانات المعروضة لأغراض تعليمية وليست نصائح استثمارية
          </p>
        </footer>
      </main>
    </div>
  )
}

export default App

