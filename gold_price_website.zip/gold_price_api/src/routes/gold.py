from flask import Blueprint, jsonify, request
from flask_cors import cross_origin
import pandas as pd
import numpy as np
import os
from datetime import datetime, timedelta
import random

gold_bp = Blueprint('gold', __name__)

# Load data
def load_gold_data():
    try:
        gold_df = pd.read_csv(os.path.join(os.path.dirname(__file__), '..', 'gold_prices.csv'))
        gold_df['Date'] = pd.to_datetime(gold_df['Date'])
        return gold_df
    except Exception as e:
        print(f"Error loading gold data: {e}")
        return None

def load_macro_data():
    try:
        macro_df = pd.read_csv(os.path.join(os.path.dirname(__file__), '..', 'macro_economic_data.csv'))
        return macro_df
    except Exception as e:
        print(f"Error loading macro data: {e}")
        return None

@gold_bp.route('/current-price', methods=['GET'])
@cross_origin()
def get_current_price():
    """Get current gold price with simulated real-time updates"""
    base_price = 2390.50
    # Simulate price fluctuation
    change = random.uniform(-20, 20)
    current_price = base_price + change
    price_change = change
    percentage_change = (change / base_price) * 100
    
    return jsonify({
        'price': round(current_price, 2),
        'change': round(price_change, 2),
        'percentage_change': round(percentage_change, 3),
        'timestamp': datetime.now().isoformat()
    })

@gold_bp.route('/historical-prices', methods=['GET'])
@cross_origin()
def get_historical_prices():
    """Get historical gold prices"""
    timeframe = request.args.get('timeframe', '1Y')
    
    gold_df = load_gold_data()
    if gold_df is None:
        return jsonify({'error': 'Failed to load gold data'}), 500
    
    # Filter data based on timeframe
    end_date = gold_df['Date'].max()
    if timeframe == '1M':
        start_date = end_date - timedelta(days=30)
    elif timeframe == '3M':
        start_date = end_date - timedelta(days=90)
    elif timeframe == '6M':
        start_date = end_date - timedelta(days=180)
    else:  # 1Y
        start_date = end_date - timedelta(days=365)
    
    filtered_df = gold_df[gold_df['Date'] >= start_date]
    
    # Convert to format suitable for frontend
    data = []
    for _, row in filtered_df.iterrows():
        data.append({
            'date': row['Date'].strftime('%Y-%m-%d'),
            'price': round(row['Close'], 2)
        })
    
    return jsonify(data)

@gold_bp.route('/economic-factors', methods=['GET'])
@cross_origin()
def get_economic_factors():
    """Get current economic factors affecting gold prices"""
    # Simulate current economic data
    factors = [
        {
            'name': 'التضخم',
            'value': round(random.uniform(2.5, 4.0), 1),
            'trend': random.choice(['up', 'down']),
            'impact': 'إيجابي'
        },
        {
            'name': 'أسعار الفائدة',
            'value': round(random.uniform(4.5, 6.0), 2),
            'trend': random.choice(['up', 'down']),
            'impact': random.choice(['إيجابي', 'سلبي'])
        },
        {
            'name': 'قوة الدولار',
            'value': round(random.uniform(100, 110), 1),
            'trend': random.choice(['up', 'down']),
            'impact': random.choice(['إيجابي', 'سلبي'])
        },
        {
            'name': 'التوترات الجيوسياسية',
            'value': round(random.uniform(6.0, 9.0), 1),
            'trend': random.choice(['up', 'down']),
            'impact': 'إيجابي'
        }
    ]
    
    return jsonify(factors)

@gold_bp.route('/recommendations', methods=['GET'])
@cross_origin()
def get_recommendations():
    """Get AI-powered trading recommendations"""
    recommendations = [
        {
            'type': random.choice(['شراء', 'بيع', 'احتفاظ']),
            'confidence': random.randint(60, 95),
            'reason': 'توقع ارتفاع الأسعار بناءً على التحليل الفني والعوامل الاقتصادية',
            'target_price': round(random.uniform(2300, 2500), 2),
            'stop_loss': round(random.uniform(2200, 2300), 2)
        },
        {
            'type': random.choice(['شراء', 'بيع', 'احتفاظ']),
            'confidence': random.randint(60, 95),
            'reason': 'استقرار نسبي في المؤشرات الاقتصادية مع توقعات إيجابية',
            'target_price': round(random.uniform(2350, 2450), 2),
            'stop_loss': round(random.uniform(2250, 2350), 2)
        },
        {
            'type': random.choice(['مراقبة', 'احتفاظ']),
            'confidence': random.randint(50, 80),
            'reason': 'تقلبات محتملة بسبب الأحداث الجيوسياسية والسياسات النقدية',
            'target_price': round(random.uniform(2400, 2500), 2),
            'stop_loss': round(random.uniform(2300, 2400), 2)
        }
    ]
    
    return jsonify(recommendations)

@gold_bp.route('/predictions', methods=['GET'])
@cross_origin()
def get_predictions():
    """Get price predictions for different time horizons"""
    current_price = 2390.50
    
    predictions = {
        'short_term': {  # 1 week
            'price': round(current_price + random.uniform(-50, 100), 2),
            'confidence': random.randint(70, 85),
            'timeframe': '1 أسبوع'
        },
        'medium_term': {  # 1 month
            'price': round(current_price + random.uniform(-100, 150), 2),
            'confidence': random.randint(60, 75),
            'timeframe': '1 شهر'
        },
        'long_term': {  # 6 months
            'price': round(current_price + random.uniform(-200, 300), 2),
            'confidence': random.randint(50, 70),
            'timeframe': '6 أشهر'
        }
    }
    
    return jsonify(predictions)

@gold_bp.route('/news', methods=['GET'])
@cross_origin()
def get_news():
    """Get latest news affecting gold prices"""
    news = [
        {
            'title': 'البنك المركزي الأمريكي يشير إلى تغييرات محتملة في أسعار الفائدة',
            'summary': 'تصريحات جديدة من البنك المركزي قد تؤثر على أسعار الذهب في الأسابيع القادمة',
            'impact': 'متوسط',
            'timestamp': (datetime.now() - timedelta(hours=2)).isoformat()
        },
        {
            'title': 'تطورات جيوسياسية جديدة تزيد الطلب على الملاذات الآمنة',
            'summary': 'الأحداث الجيوسياسية الأخيرة تدفع المستثمرين نحو الذهب كملاذ آمن',
            'impact': 'عالي',
            'timestamp': (datetime.now() - timedelta(hours=5)).isoformat()
        },
        {
            'title': 'بيانات التضخم الجديدة تظهر اتجاهاً متصاعداً',
            'summary': 'أرقام التضخم الأخيرة قد تؤثر على قرارات السياسة النقدية وأسعار الذهب',
            'impact': 'متوسط',
            'timestamp': (datetime.now() - timedelta(hours=8)).isoformat()
        }
    ]
    
    return jsonify(news)

@gold_bp.route('/portfolio', methods=['GET', 'POST'])
@cross_origin()
def portfolio():
    """Handle portfolio operations"""
    if request.method == 'GET':
        # Return mock portfolio data
        portfolio_data = {
            'total_value': round(random.uniform(50000, 150000), 2),
            'total_gold_oz': round(random.uniform(20, 60), 2),
            'average_buy_price': round(random.uniform(2200, 2350), 2),
            'current_profit_loss': round(random.uniform(-5000, 15000), 2),
            'positions': [
                {
                    'date': '2024-01-15',
                    'quantity': 10.5,
                    'buy_price': 2250.00,
                    'current_value': 10.5 * 2390.50
                },
                {
                    'date': '2024-03-20',
                    'quantity': 8.2,
                    'buy_price': 2180.00,
                    'current_value': 8.2 * 2390.50
                }
            ]
        }
        return jsonify(portfolio_data)
    
    elif request.method == 'POST':
        # Add new position (mock implementation)
        data = request.get_json()
        return jsonify({'message': 'تم إضافة الصفقة بنجاح', 'success': True})

@gold_bp.route('/alerts', methods=['GET', 'POST', 'DELETE'])
@cross_origin()
def alerts():
    """Handle price alerts"""
    if request.method == 'GET':
        # Return mock alerts
        alerts_data = [
            {
                'id': 1,
                'type': 'price_above',
                'value': 2450.00,
                'active': True,
                'created_at': '2024-12-01'
            },
            {
                'id': 2,
                'type': 'price_below',
                'value': 2300.00,
                'active': True,
                'created_at': '2024-12-01'
            }
        ]
        return jsonify(alerts_data)
    
    elif request.method == 'POST':
        # Create new alert (mock implementation)
        data = request.get_json()
        return jsonify({'message': 'تم إنشاء التنبيه بنجاح', 'success': True, 'alert_id': random.randint(100, 999)})
    
    elif request.method == 'DELETE':
        # Delete alert (mock implementation)
        alert_id = request.args.get('id')
        return jsonify({'message': 'تم حذف التنبيه بنجاح', 'success': True})

